﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WunschListeWpfApplication 
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
		double ergebnis = 0.00;
        public MainWindow()
        {
            InitializeComponent();
			listbox.AddHandler(ListBox.MouseDownEvent, new MouseButtonEventHandler(ListBox_MouseDown), true);

        }

		private void ListBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			//MessageBox.Show("Geklickt wurde" + (listbox.SelectedItem as Things).bezeichnung);
			Things wunsch = listbox.SelectedItem as Things;
			DataObject data = new DataObject(wunsch);
			DragDrop.DoDragDrop(listbox, data, DragDropEffects.Copy);
		}

		private void Canvas_DragEnter(object sender, DragEventArgs e)
		{
			//wunschzettel.Background = Brushes.DodgerBlue;
		}

		private void Canvas_DragLeave(object sender, DragEventArgs e)
		{
			//wunschzettel.Background = Brushes.PowderBlue;
		}

		private void Canvas_DragOver(object sender, DragEventArgs e)
		{
			//label.Content = "Bitte fallen lassen";
		}

		private void Canvas_Drop(object sender, DragEventArgs e)
		{
			Things kopie = (Things)e.Data.GetData(typeof(Things));
			Canvas canvas = e.Source as Canvas;
			Point p = e.GetPosition(canvas); //WO steht die Maus beim Drop
			ContentControl cc = new ContentControl();
			cc.Content = kopie;
			Canvas.SetLeft(cc, p.X);
			Canvas.SetTop(cc, p.Y);
			wunschzettel.Children.Add(cc);
			
			
			ergebnis += kopie.preis;
			label.Content = ergebnis;
		}
	}
}
